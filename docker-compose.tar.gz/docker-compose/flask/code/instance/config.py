# instance/config.py

SECRET_KEY = 'p9Bv<3Eid9%$i01'
#SQLALCHEMY_DATABASE_URI = 'mysql://kgustafson:example@localhost/db'
SQLALCHEMY_DATABASE_URI = 'mysql://root:example@db/acronym'
#SQLALCHEMY_DATABASE_URI = 'mysql://root:example@172.20.0.2/db'
#SQLALCHEMY_DATABASE_URI = 'http://localhost:3306'
